
import React, { useEffect, useState } from 'react'
import { MapPin, Plus, Search, Calendar, Users, FileText, Camera, Eye } from 'lucide-react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

interface VisitaTecnica {
  _id: string
  titulo: string
  local: string
  endereco?: string
  dataVisita: string
  horario?: string
  responsavel: string
  participantes?: string[]
  objetivos?: string
  atividades?: string
  observacoes?: string
  resultados?: string
  status: 'planejada' | 'realizada' | 'cancelada' | 'adiada'
  relatorioUrl?: string
  fotos?: string[]
}

const VisitasTecnicas: React.FC = () => {
  const [visitas, setVisitas] = useState<VisitaTecnica[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('todos')
  const [showModal, setShowModal] = useState(false)
  const [selectedVisita, setSelectedVisita] = useState<VisitaTecnica | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [showPhotosModal, setShowPhotosModal] = useState(false)
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([])

  useEffect(() => {
    fetchVisitas()
  }, [])

  const fetchVisitas = async () => {
    try {
      setLoading(true)
      const response = await lumi.entities.visitasTecnicas.list()
      setVisitas(response.list || [])
    } catch (error) {
      console.error('Erro ao carregar visitas técnicas:', error)
      toast.error('Erro ao carregar lista de visitas técnicas')
    } finally {
      setLoading(false)
    }
  }

  const filteredVisitas = visitas.filter(visita => {
    const matchesSearch = visita.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         visita.local.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         visita.responsavel.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = filterStatus === 'todos' || visita.status === filterStatus
    
    return matchesSearch && matchesFilter
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'realizada':
        return 'bg-green-100 text-green-800'
      case 'planejada':
        return 'bg-blue-100 text-blue-800'
      case 'adiada':
        return 'bg-yellow-100 text-yellow-800'
      case 'cancelada':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const openModal = (visita?: VisitaTecnica) => {
    setSelectedVisita(visita || null)
    setIsEditing(!!visita)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedVisita(null)
    setIsEditing(false)
  }

  const openPhotosModal = (fotos: string[]) => {
    setSelectedPhotos(fotos)
    setShowPhotosModal(true)
  }

  const handleSubmit = async (formData: FormData) => {
    try {
      const participantes = (formData.get('participantes') as string)
        .split(',')
        .map(p => p.trim())
        .filter(p => p.length > 0)

      const fotos = (formData.get('fotos') as string)
        .split(',')
        .map(f => f.trim())
        .filter(f => f.length > 0)

      const visitaData = {
        titulo: formData.get('titulo') as string,
        local: formData.get('local') as string,
        endereco: formData.get('endereco') as string,
        dataVisita: formData.get('dataVisita') as string,
        horario: formData.get('horario') as string,
        responsavel: formData.get('responsavel') as string,
        participantes,
        objetivos: formData.get('objetivos') as string,
        atividades: formData.get('atividades') as string,
        observacoes: formData.get('observacoes') as string,
        resultados: formData.get('resultados') as string,
        status: formData.get('status') as string,
        relatorioUrl: formData.get('relatorioUrl') as string,
        fotos,
        creator: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      if (isEditing && selectedVisita) {
        await lumi.entities.visitasTecnicas.update(selectedVisita._id, visitaData)
        toast.success('Visita técnica atualizada com sucesso')
      } else {
        await lumi.entities.visitasTecnicas.create(visitaData)
        toast.success('Visita técnica cadastrada com sucesso')
      }

      closeModal()
      fetchVisitas()
    } catch (error) {
      console.error('Erro ao salvar visita técnica:', error)
      toast.error('Erro ao salvar visita técnica')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <MapPin className="h-8 w-8 mr-3 text-blue-600" />
            Visitas Técnicas
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Registro de visitas técnicas e elaboração de relatórios
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => openModal()}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Visita
          </button>
        </div>
      </div>

      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total', count: visitas.length, color: 'text-blue-600', icon: MapPin },
          { label: 'Realizadas', count: visitas.filter(v => v.status === 'realizada').length, color: 'text-green-600', icon: Calendar },
          { label: 'Planejadas', count: visitas.filter(v => v.status === 'planejada').length, color: 'text-blue-600', icon: Users },
          { label: 'Com Relatório', count: visitas.filter(v => v.relatorioUrl).length, color: 'text-purple-600', icon: FileText }
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center">
                <Icon className={`h-8 w-8 ${stat.color}`} />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className={`text-2xl font-semibold ${stat.color}`}>{stat.count}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por título, local ou responsável..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todos os status</option>
              <option value="planejada">Planejada</option>
              <option value="realizada">Realizada</option>
              <option value="adiada">Adiada</option>
              <option value="cancelada">Cancelada</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <MapPin className="h-4 w-4" />
            <span>{filteredVisitas.length} visita(s) encontrada(s)</span>
          </div>
        </div>
      </div>

      {/* Lista de visitas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredVisitas.map((visita) => (
          <div key={visita._id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{visita.titulo}</h3>
                  <div className="flex items-center text-sm text-gray-600 mb-2">
                    <MapPin className="h-4 w-4 mr-1" />
                    {visita.local}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 mb-2">
                    <Calendar className="h-4 w-4 mr-1" />
                    {formatDate(visita.dataVisita)}
                    {visita.horario && ` • ${visita.horario}`}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="h-4 w-4 mr-1" />
                    {visita.responsavel}
                  </div>
                </div>
                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(visita.status)}`}>
                  {visita.status}
                </span>
              </div>

              {visita.objetivos && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600">
                    <strong>Objetivos:</strong> {visita.objetivos.substring(0, 150)}
                    {visita.objetivos.length > 150 && '...'}
                  </p>
                </div>
              )}

              {visita.participantes && visita.participantes.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600">
                    <strong>Participantes:</strong> {visita.participantes.slice(0, 2).join(', ')}
                    {visita.participantes.length > 2 && ` +${visita.participantes.length - 2} outros`}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  {visita.relatorioUrl && (
                    <button
                      onClick={() => window.open(visita.relatorioUrl, '_blank')}
                      className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      Relatório
                    </button>
                  )}
                  {visita.fotos && visita.fotos.length > 0 && (
                    <button
                      onClick={() => openPhotosModal(visita.fotos!)}
                      className="flex items-center text-sm text-green-600 hover:text-green-800"
                    >
                      <Camera className="h-4 w-4 mr-1" />
                      {visita.fotos.length} foto(s)
                    </button>
                  )}
                </div>
                <button
                  onClick={() => openModal(visita)}
                  className="text-sm text-gray-600 hover:text-gray-900"
                >
                  Editar
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de cadastro/edição */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {isEditing ? 'Editar Visita Técnica' : 'Nova Visita Técnica'}
              </h3>
              <form onSubmit={(e) => {
                e.preventDefault()
                handleSubmit(new FormData(e.currentTarget))
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Título *</label>
                    <input
                      type="text"
                      name="titulo"
                      required
                      defaultValue={selectedVisita?.titulo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Local *</label>
                    <input
                      type="text"
                      name="local"
                      required
                      defaultValue={selectedVisita?.local || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Responsável *</label>
                    <input
                      type="text"
                      name="responsavel"
                      required
                      defaultValue={selectedVisita?.responsavel || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data da Visita *</label>
                    <input
                      type="date"
                      name="dataVisita"
                      required
                      defaultValue={selectedVisita?.dataVisita ? selectedVisita.dataVisita.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Horário</label>
                    <input
                      type="text"
                      name="horario"
                      placeholder="Ex: 14:00 às 17:00"
                      defaultValue={selectedVisita?.horario || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                    <select
                      name="status"
                      required
                      defaultValue={selectedVisita?.status || 'planejada'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="planejada">Planejada</option>
                      <option value="realizada">Realizada</option>
                      <option value="adiada">Adiada</option>
                      <option value="cancelada">Cancelada</option>
                    </select>
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Endereço Completo</label>
                  <input
                    type="text"
                    name="endereco"
                    defaultValue={selectedVisita?.endereco || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Participantes (separados por vírgula)</label>
                  <input
                    type="text"
                    name="participantes"
                    defaultValue={selectedVisita?.participantes?.join(', ') || ''}
                    placeholder="Turma GI-2024-A, Prof. Maria Santos, Coord. João Silva"
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Objetivos</label>
                  <textarea
                    name="objetivos"
                    rows={3}
                    defaultValue={selectedVisita?.objetivos || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Atividades Realizadas</label>
                  <textarea
                    name="atividades"
                    rows={3}
                    defaultValue={selectedVisita?.atividades || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                  <textarea
                    name="observacoes"
                    rows={3}
                    defaultValue={selectedVisita?.observacoes || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Resultados Obtidos</label>
                  <textarea
                    name="resultados"
                    rows={3}
                    defaultValue={selectedVisita?.resultados || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">URL do Relatório</label>
                    <input
                      type="url"
                      name="relatorioUrl"
                      defaultValue={selectedVisita?.relatorioUrl || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">URLs das Fotos (separadas por vírgula)</label>
                    <input
                      type="text"
                      name="fotos"
                      defaultValue={selectedVisita?.fotos?.join(', ') || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {isEditing ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de fotos */}
      {showPhotosModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Fotos da Visita</h3>
                <button
                  onClick={() => setShowPhotosModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedPhotos.map((foto, index) => (
                  <div key={index} className="relative">
                    <img
                      src={foto}
                      alt={`Foto ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default VisitasTecnicas
