
import React, { useEffect, useState } from 'react'
import { FileText, Plus, Search, Filter, Download, Eye, Edit, Folder } from 'lucide-react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

interface Documento {
  _id: string
  titulo: string
  tipo: 'ata' | 'relatório' | 'ofício' | 'certificado' | 'contrato' | 'projeto' | 'outros'
  categoria: 'administrativo' | 'pedagógico' | 'financeiro' | 'jurídico' | 'institucional'
  numero?: string
  dataDocumento: string
  autor?: string
  destinatario?: string
  assunto?: string
  descricao?: string
  status: 'rascunho' | 'finalizado' | 'enviado' | 'arquivado'
  arquivoUrl?: string
  palavrasChave?: string[]
}

const Documentos: React.FC = () => {
  const [documentos, setDocumentos] = useState<Documento[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategoria, setFilterCategoria] = useState<string>('todas')
  const [filterTipo, setFilterTipo] = useState<string>('todos')
  const [showModal, setShowModal] = useState(false)
  const [selectedDocumento, setSelectedDocumento] = useState<Documento | null>(null)
  const [isEditing, setIsEditing] = useState(false)

  useEffect(() => {
    fetchDocumentos()
  }, [])

  const fetchDocumentos = async () => {
    try {
      setLoading(true)
      const response = await lumi.entities.documentos.list()
      setDocumentos(response.list || [])
    } catch (error) {
      console.error('Erro ao carregar documentos:', error)
      toast.error('Erro ao carregar lista de documentos')
    } finally {
      setLoading(false)
    }
  }

  const filteredDocumentos = documentos.filter(documento => {
    const matchesSearch = documento.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         documento.assunto?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         documento.autor?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         documento.palavrasChave?.some(palavra => 
                           palavra.toLowerCase().includes(searchTerm.toLowerCase())
                         )
    
    const matchesCategoria = filterCategoria === 'todas' || documento.categoria === filterCategoria
    const matchesTipo = filterTipo === 'todos' || documento.tipo === filterTipo
    
    return matchesSearch && matchesCategoria && matchesTipo
  })

  const getCategoriaColor = (categoria: string) => {
    switch (categoria) {
      case 'administrativo':
        return 'bg-blue-100 text-blue-800'
      case 'pedagógico':
        return 'bg-green-100 text-green-800'
      case 'financeiro':
        return 'bg-yellow-100 text-yellow-800'
      case 'jurídico':
        return 'bg-red-100 text-red-800'
      case 'institucional':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'finalizado':
        return 'bg-green-100 text-green-800'
      case 'enviado':
        return 'bg-blue-100 text-blue-800'
      case 'arquivado':
        return 'bg-gray-100 text-gray-800'
      case 'rascunho':
        return 'bg-yellow-100 text-yellow-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const openModal = (documento?: Documento) => {
    setSelectedDocumento(documento || null)
    setIsEditing(!!documento)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedDocumento(null)
    setIsEditing(false)
  }

  const handleSubmit = async (formData: FormData) => {
    try {
      const palavrasChave = (formData.get('palavrasChave') as string)
        .split(',')
        .map(palavra => palavra.trim())
        .filter(palavra => palavra.length > 0)

      const documentoData = {
        titulo: formData.get('titulo') as string,
        tipo: formData.get('tipo') as string,
        categoria: formData.get('categoria') as string,
        numero: formData.get('numero') as string,
        dataDocumento: formData.get('dataDocumento') as string,
        autor: formData.get('autor') as string,
        destinatario: formData.get('destinatario') as string,
        assunto: formData.get('assunto') as string,
        descricao: formData.get('descricao') as string,
        status: formData.get('status') as string,
        arquivoUrl: formData.get('arquivoUrl') as string,
        palavrasChave,
        creator: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      if (isEditing && selectedDocumento) {
        await lumi.entities.documentos.update(selectedDocumento._id, documentoData)
        toast.success('Documento atualizado com sucesso')
      } else {
        await lumi.entities.documentos.create(documentoData)
        toast.success('Documento cadastrado com sucesso')
      }

      closeModal()
      fetchDocumentos()
    } catch (error) {
      console.error('Erro ao salvar documento:', error)
      toast.error('Erro ao salvar documento')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <FileText className="h-8 w-8 mr-3 text-blue-600" />
            Controle de Documentos
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Gestão de arquivos e documentos institucionais da PRECAVI
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => openModal()}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Novo Documento
          </button>
        </div>
      </div>

      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total', count: documentos.length, color: 'text-blue-600' },
          { label: 'Finalizados', count: documentos.filter(d => d.status === 'finalizado').length, color: 'text-green-600' },
          { label: 'Em Rascunho', count: documentos.filter(d => d.status === 'rascunho').length, color: 'text-yellow-600' },
          { label: 'Arquivados', count: documentos.filter(d => d.status === 'arquivado').length, color: 'text-gray-600' }
        ].map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center">
              <Folder className={`h-8 w-8 ${stat.color}`} />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className={`text-2xl font-semibold ${stat.color}`}>{stat.count}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar documentos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <select
              value={filterCategoria}
              onChange={(e) => setFilterCategoria(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todas">Todas as categorias</option>
              <option value="administrativo">Administrativo</option>
              <option value="pedagógico">Pedagógico</option>
              <option value="financeiro">Financeiro</option>
              <option value="jurídico">Jurídico</option>
              <option value="institucional">Institucional</option>
            </select>
          </div>
          <div className="relative">
            <Filter className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <select
              value={filterTipo}
              onChange={(e) => setFilterTipo(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todos os tipos</option>
              <option value="ata">Ata</option>
              <option value="relatório">Relatório</option>
              <option value="ofício">Ofício</option>
              <option value="certificado">Certificado</option>
              <option value="contrato">Contrato</option>
              <option value="projeto">Projeto</option>
              <option value="outros">Outros</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <FileText className="h-4 w-4" />
            <span>{filteredDocumentos.length} documento(s) encontrado(s)</span>
          </div>
        </div>
      </div>

      {/* Lista de documentos */}
      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Documento
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Categoria/Tipo
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Autor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDocumentos.map((documento) => (
                <tr key={documento._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{documento.titulo}</div>
                      <div className="text-sm text-gray-500">
                        {documento.numero && `${documento.numero} • `}
                        {documento.assunto}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getCategoriaColor(documento.categoria)}`}>
                      {documento.categoria}
                    </span>
                    <div className="text-sm text-gray-500 mt-1 capitalize">{documento.tipo}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {documento.autor || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(documento.dataDocumento)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(documento.status)}`}>
                      {documento.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      {documento.arquivoUrl && (
                        <button
                          onClick={() => window.open(documento.arquivoUrl, '_blank')}
                          className="text-green-600 hover:text-green-900"
                          title="Visualizar arquivo"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                      )}
                      <button
                        onClick={() => openModal(documento)}
                        className="text-blue-600 hover:text-blue-900"
                        title="Editar documento"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de cadastro/edição */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {isEditing ? 'Editar Documento' : 'Novo Documento'}
              </h3>
              <form onSubmit={(e) => {
                e.preventDefault()
                handleSubmit(new FormData(e.currentTarget))
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Título *</label>
                    <input
                      type="text"
                      name="titulo"
                      required
                      defaultValue={selectedDocumento?.titulo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tipo *</label>
                    <select
                      name="tipo"
                      required
                      defaultValue={selectedDocumento?.tipo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="">Selecione o tipo</option>
                      <option value="ata">Ata</option>
                      <option value="relatório">Relatório</option>
                      <option value="ofício">Ofício</option>
                      <option value="certificado">Certificado</option>
                      <option value="contrato">Contrato</option>
                      <option value="projeto">Projeto</option>
                      <option value="outros">Outros</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Categoria *</label>
                    <select
                      name="categoria"
                      required
                      defaultValue={selectedDocumento?.categoria || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="">Selecione a categoria</option>
                      <option value="administrativo">Administrativo</option>
                      <option value="pedagógico">Pedagógico</option>
                      <option value="financeiro">Financeiro</option>
                      <option value="jurídico">Jurídico</option>
                      <option value="institucional">Institucional</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Número</label>
                    <input
                      type="text"
                      name="numero"
                      defaultValue={selectedDocumento?.numero || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data do Documento *</label>
                    <input
                      type="date"
                      name="dataDocumento"
                      required
                      defaultValue={selectedDocumento?.dataDocumento ? selectedDocumento.dataDocumento.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Autor</label>
                    <input
                      type="text"
                      name="autor"
                      defaultValue={selectedDocumento?.autor || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Destinatário</label>
                    <input
                      type="text"
                      name="destinatario"
                      defaultValue={selectedDocumento?.destinatario || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                    <select
                      name="status"
                      required
                      defaultValue={selectedDocumento?.status || 'rascunho'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="rascunho">Rascunho</option>
                      <option value="finalizado">Finalizado</option>
                      <option value="enviado">Enviado</option>
                      <option value="arquivado">Arquivado</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">URL do Arquivo</label>
                    <input
                      type="url"
                      name="arquivoUrl"
                      defaultValue={selectedDocumento?.arquivoUrl || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Assunto</label>
                  <input
                    type="text"
                    name="assunto"
                    defaultValue={selectedDocumento?.assunto || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                  <textarea
                    name="descricao"
                    rows={3}
                    defaultValue={selectedDocumento?.descricao || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Palavras-chave (separadas por vírgula)</label>
                  <input
                    type="text"
                    name="palavrasChave"
                    defaultValue={selectedDocumento?.palavrasChave?.join(', ') || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="documento, relatório, institucional"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {isEditing ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Documentos
