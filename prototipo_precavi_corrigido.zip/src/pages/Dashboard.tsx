
import React, { useEffect, useState } from 'react'
import { 
  Users, 
  FileText, 
  MapPin, 
  Calendar, 
  CheckSquare, 
  TrendingUp,
  Award,
  Building2
} from 'lucide-react'
import { lumi } from '../lib/lumi'

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState({
    alunos: { total: 0, ativos: 0, egressos: 0 },
    documentos: { total: 0, finalizados: 0 },
    visitas: { total: 0, realizadas: 0 },
    eventos: { total: 0, concluidos: 0 },
    tarefas: { total: 0, concluidas: 0, pendentes: 0 }
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true)
        
        // Buscar estatísticas de cada entidade
        const [alunos, documentos, visitas, eventos, tarefas] = await Promise.all([
          lumi.entities.alunos.list(),
          lumi.entities.documentos.list(),
          lumi.entities.visitasTecnicas.list(),
          lumi.entities.eventos.list(),
          lumi.entities.tarefas.list()
        ])

        setStats({
          alunos: {
            total: alunos.list?.length || 0,
            ativos: alunos.list?.filter(a => a.situacao === 'ativo').length || 0,
            egressos: alunos.list?.filter(a => a.situacao === 'egresso').length || 0
          },
          documentos: {
            total: documentos.list?.length || 0,
            finalizados: documentos.list?.filter(d => d.status === 'finalizado').length || 0
          },
          visitas: {
            total: visitas.list?.length || 0,
            realizadas: visitas.list?.filter(v => v.status === 'realizada').length || 0
          },
          eventos: {
            total: eventos.list?.length || 0,
            concluidos: eventos.list?.filter(e => e.status === 'concluído').length || 0
          },
          tarefas: {
            total: tarefas.list?.length || 0,
            concluidas: tarefas.list?.filter(t => t.status === 'concluída').length || 0,
            pendentes: tarefas.list?.filter(t => t.status === 'pendente').length || 0
          }
        })
      } catch (error) {
        console.error('Erro ao carregar estatísticas:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  const cards = [
    {
      title: 'Alunos Ativos',
      value: stats.alunos.ativos,
      total: stats.alunos.total,
      icon: Users,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    {
      title: 'Documentos',
      value: stats.documentos.finalizados,
      total: stats.documentos.total,
      icon: FileText,
      color: 'bg-green-500',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600'
    },
    {
      title: 'Visitas Realizadas',
      value: stats.visitas.realizadas,
      total: stats.visitas.total,
      icon: MapPin,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    },
    {
      title: 'Eventos',
      value: stats.eventos.concluidos,
      total: stats.eventos.total,
      icon: Calendar,
      color: 'bg-orange-500',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600'
    },
    {
      title: 'Tarefas Concluídas',
      value: stats.tarefas.concluidas,
      total: stats.tarefas.total,
      icon: CheckSquare,
      color: 'bg-indigo-500',
      bgColor: 'bg-indigo-50',
      textColor: 'text-indigo-600'
    }
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-6 text-white">
          <div className="flex items-center">
            <Building2 className="h-12 w-12 mr-4" />
            <div>
              <h1 className="text-3xl font-bold">Sistema PRECAVI</h1>
              <p className="text-blue-100 mt-2">
                Gestão Administrativa - Associação PRECAVI - Vida Nova
              </p>
              <p className="text-blue-200 text-sm mt-1">
                Sistema de apoio técnico-pedagógico para desenvolvimento institucional
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Cards de estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {cards.map((card, index) => {
          const Icon = card.icon
          return (
            <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center">
                <div className={`${card.bgColor} p-3 rounded-lg`}>
                  <Icon className={`h-6 w-6 ${card.textColor}`} />
                </div>
                <div className="ml-4 flex-1">
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-gray-900">{card.value}</p>
                    <p className="ml-2 text-sm text-gray-500">/ {card.total}</p>
                  </div>
                </div>
              </div>
              {card.total > 0 && (
                <div className="mt-4">
                  <div className="bg-gray-200 rounded-full h-2">
                    <div 
                      className={`${card.color} h-2 rounded-full`}
                      style={{ width: `${(card.value / card.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Informações institucionais */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Award className="h-5 w-5 mr-2 text-blue-600" />
            Missão Institucional
          </h3>
          <p className="text-gray-600 leading-relaxed">
            Promover educação profissional transformadora que dialogue com a realidade e 
            contribua com o desenvolvimento socioeconômico e humano da nossa região, 
            fortalecendo nossa missão institucional.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
            Áreas de Atuação
          </h3>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-start">
              <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
              Controle de arquivos e documentos institucionais
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
              Organização das fichas de matrícula de alunos
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
              Registro de visitas técnicas e relatórios
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
              Gerenciamento de ações e eventos
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
