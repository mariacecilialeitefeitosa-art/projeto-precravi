
import React, { useEffect, useState } from 'react'
import { Calendar, Plus, Search, Users, Camera, MapPin, Clock, FileText, Eye } from 'lucide-react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

interface Evento {
  _id: string
  titulo: string
  tipo: 'curso' | 'workshop' | 'palestra' | 'evento' | 'ação social' | 'reunião' | 'outros'
  descricao?: string
  dataInicio: string
  dataFim?: string
  horario?: string
  local?: string
  endereco?: string
  responsavel: string
  participantes?: string[]
  capacidade?: number
  inscritos?: number
  status: 'planejado' | 'em andamento' | 'concluído' | 'cancelado' | 'adiado'
  recursos?: string[]
  orcamento?: number
  fotos?: Array<{
    url: string
    legenda?: string
    data: string
  }>
  relatorioUrl?: string
}

const Eventos: React.FC = () => {
  const [eventos, setEventos] = useState<Evento[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('todos')
  const [filterTipo, setFilterTipo] = useState<string>('todos')
  const [showModal, setShowModal] = useState(false)
  const [selectedEvento, setSelectedEvento] = useState<Evento | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [showPhotosModal, setShowPhotosModal] = useState(false)
  const [selectedPhotos, setSelectedPhotos] = useState<Array<{ url: string; legenda?: string; data: string }>>([])

  useEffect(() => {
    fetchEventos()
  }, [])

  const fetchEventos = async () => {
    try {
      setLoading(true)
      const response = await lumi.entities.eventos.list()
      setEventos(response.list || [])
    } catch (error) {
      console.error('Erro ao carregar eventos:', error)
      toast.error('Erro ao carregar lista de eventos')
    } finally {
      setLoading(false)
    }
  }

  const filteredEventos = eventos.filter(evento => {
    const matchesSearch = evento.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         evento.local?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         evento.responsavel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         evento.descricao?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = filterStatus === 'todos' || evento.status === filterStatus
    const matchesTipo = filterTipo === 'todos' || evento.tipo === filterTipo
    
    return matchesSearch && matchesStatus && matchesTipo
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'concluído':
        return 'bg-green-100 text-green-800'
      case 'em andamento':
        return 'bg-blue-100 text-blue-800'
      case 'planejado':
        return 'bg-yellow-100 text-yellow-800'
      case 'adiado':
        return 'bg-orange-100 text-orange-800'
      case 'cancelado':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case 'curso':
        return 'bg-blue-100 text-blue-800'
      case 'workshop':
        return 'bg-green-100 text-green-800'
      case 'palestra':
        return 'bg-purple-100 text-purple-800'
      case 'ação social':
        return 'bg-pink-100 text-pink-800'
      case 'evento':
        return 'bg-indigo-100 text-indigo-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const openModal = (evento?: Evento) => {
    setSelectedEvento(evento || null)
    setIsEditing(!!evento)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedEvento(null)
    setIsEditing(false)
  }

  const openPhotosModal = (fotos: Array<{ url: string; legenda?: string; data: string }>) => {
    setSelectedPhotos(fotos)
    setShowPhotosModal(true)
  }

  const handleSubmit = async (formData: FormData) => {
    try {
      const participantes = (formData.get('participantes') as string)
        .split(',')
        .map(p => p.trim())
        .filter(p => p.length > 0)

      const recursos = (formData.get('recursos') as string)
        .split(',')
        .map(r => r.trim())
        .filter(r => r.length > 0)

      const eventoData = {
        titulo: formData.get('titulo') as string,
        tipo: formData.get('tipo') as string,
        descricao: formData.get('descricao') as string,
        dataInicio: formData.get('dataInicio') as string,
        dataFim: formData.get('dataFim') as string,
        horario: formData.get('horario') as string,
        local: formData.get('local') as string,
        endereco: formData.get('endereco') as string,
        responsavel: formData.get('responsavel') as string,
        participantes,
        capacidade: parseInt(formData.get('capacidade') as string) || 0,
        inscritos: parseInt(formData.get('inscritos') as string) || 0,
        status: formData.get('status') as string,
        recursos,
        orcamento: parseFloat(formData.get('orcamento') as string) || 0,
        relatorioUrl: formData.get('relatorioUrl') as string,
        fotos: [],
        creator: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      if (isEditing && selectedEvento) {
        await lumi.entities.eventos.update(selectedEvento._id, eventoData)
        toast.success('Evento atualizado com sucesso')
      } else {
        await lumi.entities.eventos.create(eventoData)
        toast.success('Evento cadastrado com sucesso')
      }

      closeModal()
      fetchEventos()
    } catch (error) {
      console.error('Erro ao salvar evento:', error)
      toast.error('Erro ao salvar evento')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <Calendar className="h-8 w-8 mr-3 text-blue-600" />
            Gerenciamento de Eventos
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Controle de ações e eventos incluindo banco de fotos
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => openModal()}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Novo Evento
          </button>
        </div>
      </div>

      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total', count: eventos.length, color: 'text-blue-600', icon: Calendar },
          { label: 'Concluídos', count: eventos.filter(e => e.status === 'concluído').length, color: 'text-green-600', icon: Calendar },
          { label: 'Em Andamento', count: eventos.filter(e => e.status === 'em andamento').length, color: 'text-blue-600', icon: Clock },
          { label: 'Com Fotos', count: eventos.filter(e => e.fotos && e.fotos.length > 0).length, color: 'text-purple-600', icon: Camera }
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center">
                <Icon className={`h-8 w-8 ${stat.color}`} />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className={`text-2xl font-semibold ${stat.color}`}>{stat.count}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar eventos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <select
              value={filterTipo}
              onChange={(e) => setFilterTipo(e.target.value)}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todos os tipos</option>
              <option value="curso">Curso</option>
              <option value="workshop">Workshop</option>
              <option value="palestra">Palestra</option>
              <option value="evento">Evento</option>
              <option value="ação social">Ação Social</option>
              <option value="reunião">Reunião</option>
              <option value="outros">Outros</option>
            </select>
          </div>
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todos os status</option>
              <option value="planejado">Planejado</option>
              <option value="em andamento">Em Andamento</option>
              <option value="concluído">Concluído</option>
              <option value="adiado">Adiado</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Calendar className="h-4 w-4" />
            <span>{filteredEventos.length} evento(s) encontrado(s)</span>
          </div>
        </div>
      </div>

      {/* Lista de eventos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredEventos.map((evento) => (
          <div key={evento._id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{evento.titulo}</h3>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getTipoColor(evento.tipo)}`}>
                      {evento.tipo}
                    </span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(evento.status)}`}>
                      {evento.status}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  {formatDate(evento.dataInicio)}
                  {evento.dataFim && evento.dataFim !== evento.dataInicio && ` - ${formatDate(evento.dataFim)}`}
                </div>
                {evento.horario && (
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="h-4 w-4 mr-2" />
                    {evento.horario}
                  </div>
                )}
                {evento.local && (
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    {evento.local}
                  </div>
                )}
                <div className="flex items-center text-sm text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  {evento.responsavel}
                </div>
              </div>

              {evento.capacidade && evento.inscritos !== undefined && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Participantes</span>
                    <span>{evento.inscritos}/{evento.capacidade}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${Math.min((evento.inscritos / evento.capacidade) * 100, 100)}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {evento.descricao && (
                <p className="text-sm text-gray-600 mb-4">
                  {evento.descricao.substring(0, 120)}
                  {evento.descricao.length > 120 && '...'}
                </p>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  {evento.relatorioUrl && (
                    <button
                      onClick={() => window.open(evento.relatorioUrl, '_blank')}
                      className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      Relatório
                    </button>
                  )}
                  {evento.fotos && evento.fotos.length > 0 && (
                    <button
                      onClick={() => openPhotosModal(evento.fotos!)}
                      className="flex items-center text-sm text-green-600 hover:text-green-800"
                    >
                      <Camera className="h-4 w-4 mr-1" />
                      {evento.fotos.length} foto(s)
                    </button>
                  )}
                </div>
                <button
                  onClick={() => openModal(evento)}
                  className="text-sm text-gray-600 hover:text-gray-900"
                >
                  Editar
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de cadastro/edição */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {isEditing ? 'Editar Evento' : 'Novo Evento'}
              </h3>
              <form onSubmit={(e) => {
                e.preventDefault()
                handleSubmit(new FormData(e.currentTarget))
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Título *</label>
                    <input
                      type="text"
                      name="titulo"
                      required
                      defaultValue={selectedEvento?.titulo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tipo *</label>
                    <select
                      name="tipo"
                      required
                      defaultValue={selectedEvento?.tipo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="">Selecione o tipo</option>
                      <option value="curso">Curso</option>
                      <option value="workshop">Workshop</option>
                      <option value="palestra">Palestra</option>
                      <option value="evento">Evento</option>
                      <option value="ação social">Ação Social</option>
                      <option value="reunião">Reunião</option>
                      <option value="outros">Outros</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                    <select
                      name="status"
                      required
                      defaultValue={selectedEvento?.status || 'planejado'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="planejado">Planejado</option>
                      <option value="em andamento">Em Andamento</option>
                      <option value="concluído">Concluído</option>
                      <option value="adiado">Adiado</option>
                      <option value="cancelado">Cancelado</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data de Início *</label>
                    <input
                      type="date"
                      name="dataInicio"
                      required
                      defaultValue={selectedEvento?.dataInicio ? selectedEvento.dataInicio.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data de Término</label>
                    <input
                      type="date"
                      name="dataFim"
                      defaultValue={selectedEvento?.dataFim ? selectedEvento.dataFim.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Horário</label>
                    <input
                      type="text"
                      name="horario"
                      placeholder="Ex: 08:00 às 17:00"
                      defaultValue={selectedEvento?.horario || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Local</label>
                    <input
                      type="text"
                      name="local"
                      defaultValue={selectedEvento?.local || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Responsável *</label>
                    <input
                      type="text"
                      name="responsavel"
                      required
                      defaultValue={selectedEvento?.responsavel || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Capacidade</label>
                    <input
                      type="number"
                      name="capacidade"
                      min="1"
                      defaultValue={selectedEvento?.capacidade || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Inscritos</label>
                    <input
                      type="number"
                      name="inscritos"
                      min="0"
                      defaultValue={selectedEvento?.inscritos || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Orçamento (R$)</label>
                    <input
                      type="number"
                      name="orcamento"
                      step="0.01"
                      min="0"
                      defaultValue={selectedEvento?.orcamento || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Endereço Completo</label>
                  <input
                    type="text"
                    name="endereco"
                    defaultValue={selectedEvento?.endereco || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                  <textarea
                    name="descricao"
                    rows={3}
                    defaultValue={selectedEvento?.descricao || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Participantes (separados por vírgula)</label>
                  <input
                    type="text"
                    name="participantes"
                    defaultValue={selectedEvento?.participantes?.join(', ') || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Recursos Necessários (separados por vírgula)</label>
                  <input
                    type="text"
                    name="recursos"
                    defaultValue={selectedEvento?.recursos?.join(', ') || ''}
                    placeholder="Projetor, Som, Microfones, Coffee break"
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">URL do Relatório Final</label>
                  <input
                    type="url"
                    name="relatorioUrl"
                    defaultValue={selectedEvento?.relatorioUrl || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {isEditing ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de fotos */}
      {showPhotosModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Banco de Fotos do Evento</h3>
                <button
                  onClick={() => setShowPhotosModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {selectedPhotos.map((foto, index) => (
                  <div key={index} className="relative">
                    <img
                      src={foto.url}
                      alt={foto.legenda || `Foto ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    {foto.legenda && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2 rounded-b-lg">
                        <p className="text-sm">{foto.legenda}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Eventos
