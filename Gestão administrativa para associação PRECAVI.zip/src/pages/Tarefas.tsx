
import React, { useEffect, useState } from 'react'
import { CheckSquare, Plus, Search, Filter, Clock, User, FileText, Camera, AlertCircle } from 'lucide-react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

interface Tarefa {
  _id: string
  titulo: string
  descricao?: string
  responsavel: string
  colaboradores?: string[]
  prazo: string
  prioridade: 'baixa' | 'média' | 'alta' | 'urgente'
  categoria: 'administrativa' | 'pedagógica' | 'manutenção' | 'evento' | 'projeto' | 'outros'
  status: 'pendente' | 'em andamento' | 'concluída' | 'cancelada' | 'adiada'
  progresso: number
  evidencias?: Array<{
    tipo: 'foto' | 'documento' | 'relatório' | 'outros'
    url: string
    descricao?: string
    data: string
  }>
  observacoes?: string
  dataConclusao?: string
}

const Tarefas: React.FC = () => {
  const [tarefas, setTarefas] = useState<Tarefa[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState<string>('todos')
  const [filterPrioridade, setFilterPrioridade] = useState<string>('todas')
  const [showModal, setShowModal] = useState(false)
  const [selectedTarefa, setSelectedTarefa] = useState<Tarefa | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [showEvidenciasModal, setShowEvidenciasModal] = useState(false)
  const [selectedEvidencias, setSelectedEvidencias] = useState<Array<{
    tipo: string
    url: string
    descricao?: string
    data: string
  }>>([])

  useEffect(() => {
    fetchTarefas()
  }, [])

  const fetchTarefas = async () => {
    try {
      setLoading(true)
      const response = await lumi.entities.tarefas.list()
      setTarefas(response.list || [])
    } catch (error) {
      console.error('Erro ao carregar tarefas:', error)
      toast.error('Erro ao carregar lista de tarefas')
    } finally {
      setLoading(false)
    }
  }

  const filteredTarefas = tarefas.filter(tarefa => {
    const matchesSearch = tarefa.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tarefa.responsavel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tarefa.descricao?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = filterStatus === 'todos' || tarefa.status === filterStatus
    const matchesPrioridade = filterPrioridade === 'todas' || tarefa.prioridade === filterPrioridade
    
    return matchesSearch && matchesStatus && matchesPrioridade
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'concluída':
        return 'bg-green-100 text-green-800'
      case 'em andamento':
        return 'bg-blue-100 text-blue-800'
      case 'pendente':
        return 'bg-yellow-100 text-yellow-800'
      case 'adiada':
        return 'bg-orange-100 text-orange-800'
      case 'cancelada':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getPrioridadeColor = (prioridade: string) => {
    switch (prioridade) {
      case 'urgente':
        return 'bg-red-100 text-red-800'
      case 'alta':
        return 'bg-orange-100 text-orange-800'
      case 'média':
        return 'bg-yellow-100 text-yellow-800'
      case 'baixa':
        return 'bg-green-100 text-green-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getCategoriaColor = (categoria: string) => {
    switch (categoria) {
      case 'administrativa':
        return 'bg-blue-100 text-blue-800'
      case 'pedagógica':
        return 'bg-green-100 text-green-800'
      case 'manutenção':
        return 'bg-gray-100 text-gray-800'
      case 'evento':
        return 'bg-purple-100 text-purple-800'
      case 'projeto':
        return 'bg-indigo-100 text-indigo-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const isOverdue = (prazo: string, status: string) => {
    if (status === 'concluída') return false
    return new Date(prazo) < new Date()
  }

  const openModal = (tarefa?: Tarefa) => {
    setSelectedTarefa(tarefa || null)
    setIsEditing(!!tarefa)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedTarefa(null)
    setIsEditing(false)
  }

  const openEvidenciasModal = (evidencias: Array<{ tipo: string; url: string; descricao?: string; data: string }>) => {
    setSelectedEvidencias(evidencias)
    setShowEvidenciasModal(true)
  }

  const handleSubmit = async (formData: FormData) => {
    try {
      const colaboradores = (formData.get('colaboradores') as string)
        .split(',')
        .map(c => c.trim())
        .filter(c => c.length > 0)

      const tarefaData = {
        titulo: formData.get('titulo') as string,
        descricao: formData.get('descricao') as string,
        responsavel: formData.get('responsavel') as string,
        colaboradores,
        prazo: formData.get('prazo') as string,
        prioridade: formData.get('prioridade') as string,
        categoria: formData.get('categoria') as string,
        status: formData.get('status') as string,
        progresso: parseInt(formData.get('progresso') as string) || 0,
        observacoes: formData.get('observacoes') as string,
        evidencias: [],
        creator: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      if (isEditing && selectedTarefa) {
        await lumi.entities.tarefas.update(selectedTarefa._id, tarefaData)
        toast.success('Tarefa atualizada com sucesso')
      } else {
        await lumi.entities.tarefas.create(tarefaData)
        toast.success('Tarefa cadastrada com sucesso')
      }

      closeModal()
      fetchTarefas()
    } catch (error) {
      console.error('Erro ao salvar tarefa:', error)
      toast.error('Erro ao salvar tarefa')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <CheckSquare className="h-8 w-8 mr-3 text-blue-600" />
            Gestão de Tarefas
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Designação e acompanhamento de tarefas com evidências do andamento
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => openModal()}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Tarefa
          </button>
        </div>
      </div>

      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        {[
          { label: 'Total', count: tarefas.length, color: 'text-blue-600', icon: CheckSquare },
          { label: 'Pendentes', count: tarefas.filter(t => t.status === 'pendente').length, color: 'text-yellow-600', icon: Clock },
          { label: 'Em Andamento', count: tarefas.filter(t => t.status === 'em andamento').length, color: 'text-blue-600', icon: User },
          { label: 'Concluídas', count: tarefas.filter(t => t.status === 'concluída').length, color: 'text-green-600', icon: CheckSquare },
          { label: 'Atrasadas', count: tarefas.filter(t => isOverdue(t.prazo, t.status)).length, color: 'text-red-600', icon: AlertCircle }
        ].map((stat, index) => {
          const Icon = stat.icon
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center">
                <Icon className={`h-6 w-6 ${stat.color}`} />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className={`text-xl font-semibold ${stat.color}`}>{stat.count}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar tarefas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todos os status</option>
              <option value="pendente">Pendente</option>
              <option value="em andamento">Em Andamento</option>
              <option value="concluída">Concluída</option>
              <option value="adiada">Adiada</option>
              <option value="cancelada">Cancelada</option>
            </select>
          </div>
          <div className="relative">
            <Filter className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <select
              value={filterPrioridade}
              onChange={(e) => setFilterPrioridade(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todas">Todas as prioridades</option>
              <option value="urgente">Urgente</option>
              <option value="alta">Alta</option>
              <option value="média">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <CheckSquare className="h-4 w-4" />
            <span>{filteredTarefas.length} tarefa(s) encontrada(s)</span>
          </div>
        </div>
      </div>

      {/* Lista de tarefas */}
      <div className="space-y-4">
        {filteredTarefas.map((tarefa) => (
          <div key={tarefa._id} className={`bg-white rounded-lg shadow-sm border-l-4 ${
            isOverdue(tarefa.prazo, tarefa.status) ? 'border-red-500' : 
            tarefa.prioridade === 'urgente' ? 'border-red-400' :
            tarefa.prioridade === 'alta' ? 'border-orange-400' :
            'border-blue-400'
          } hover:shadow-md transition-shadow`}>
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 mr-3">{tarefa.titulo}</h3>
                    {isOverdue(tarefa.prazo, tarefa.status) && (
                      <AlertCircle className="h-5 w-5 text-red-500" title="Tarefa atrasada" />
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(tarefa.status)}`}>
                      {tarefa.status}
                    </span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPrioridadeColor(tarefa.prioridade)}`}>
                      {tarefa.prioridade}
                    </span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getCategoriaColor(tarefa.categoria)}`}>
                      {tarefa.categoria}
                    </span>
                  </div>
                  {tarefa.descricao && (
                    <p className="text-sm text-gray-600 mb-3">
                      {tarefa.descricao.substring(0, 150)}
                      {tarefa.descricao.length > 150 && '...'}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => openModal(tarefa)}
                  className="text-sm text-gray-600 hover:text-gray-900 ml-4"
                >
                  Editar
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <User className="h-4 w-4 mr-2" />
                  <span><strong>Responsável:</strong> {tarefa.responsavel}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span><strong>Prazo:</strong> {formatDate(tarefa.prazo)}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <CheckSquare className="h-4 w-4 mr-2" />
                  <span><strong>Progresso:</strong> {tarefa.progresso}%</span>
                </div>
              </div>

              {/* Barra de progresso */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Progresso</span>
                  <span>{tarefa.progresso}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      tarefa.progresso === 100 ? 'bg-green-600' :
                      tarefa.progresso >= 75 ? 'bg-blue-600' :
                      tarefa.progresso >= 50 ? 'bg-yellow-500' :
                      'bg-red-500'
                    }`}
                    style={{ width: `${tarefa.progresso}%` }}
                  ></div>
                </div>
              </div>

              {tarefa.colaboradores && tarefa.colaboradores.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600">
                    <strong>Colaboradores:</strong> {tarefa.colaboradores.join(', ')}
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  {tarefa.evidencias && tarefa.evidencias.length > 0 && (
                    <button
                      onClick={() => openEvidenciasModal(tarefa.evidencias!)}
                      className="flex items-center text-sm text-green-600 hover:text-green-800"
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      {tarefa.evidencias.length} evidência(s)
                    </button>
                  )}
                  {tarefa.dataConclusao && (
                    <span className="text-sm text-gray-500">
                      Concluída em: {formatDate(tarefa.dataConclusao)}
                    </span>
                  )}
                </div>
                <div className="text-sm text-gray-500">
                  Criada em: {formatDate(tarefa.createdAt || '')}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de cadastro/edição */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {isEditing ? 'Editar Tarefa' : 'Nova Tarefa'}
              </h3>
              <form onSubmit={(e) => {
                e.preventDefault()
                handleSubmit(new FormData(e.currentTarget))
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Título *</label>
                    <input
                      type="text"
                      name="titulo"
                      required
                      defaultValue={selectedTarefa?.titulo || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Responsável *</label>
                    <input
                      type="text"
                      name="responsavel"
                      required
                      defaultValue={selectedTarefa?.responsavel || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Prazo *</label>
                    <input
                      type="date"
                      name="prazo"
                      required
                      defaultValue={selectedTarefa?.prazo ? selectedTarefa.prazo.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Prioridade *</label>
                    <select
                      name="prioridade"
                      required
                      defaultValue={selectedTarefa?.prioridade || 'média'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="baixa">Baixa</option>
                      <option value="média">Média</option>
                      <option value="alta">Alta</option>
                      <option value="urgente">Urgente</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Categoria *</label>
                    <select
                      name="categoria"
                      required
                      defaultValue={selectedTarefa?.categoria || 'administrativa'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="administrativa">Administrativa</option>
                      <option value="pedagógica">Pedagógica</option>
                      <option value="manutenção">Manutenção</option>
                      <option value="evento">Evento</option>
                      <option value="projeto">Projeto</option>
                      <option value="outros">Outros</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                    <select
                      name="status"
                      required
                      defaultValue={selectedTarefa?.status || 'pendente'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="pendente">Pendente</option>
                      <option value="em andamento">Em Andamento</option>
                      <option value="concluída">Concluída</option>
                      <option value="adiada">Adiada</option>
                      <option value="cancelada">Cancelada</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Progresso (%)</label>
                    <input
                      type="number"
                      name="progresso"
                      min="0"
                      max="100"
                      defaultValue={selectedTarefa?.progresso || 0}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                  <textarea
                    name="descricao"
                    rows={3}
                    defaultValue={selectedTarefa?.descricao || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Colaboradores (separados por vírgula)</label>
                  <input
                    type="text"
                    name="colaboradores"
                    defaultValue={selectedTarefa?.colaboradores?.join(', ') || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                  <textarea
                    name="observacoes"
                    rows={3}
                    defaultValue={selectedTarefa?.observacoes || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {isEditing ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de evidências */}
      {showEvidenciasModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Evidências do Andamento</h3>
                <button
                  onClick={() => setShowEvidenciasModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              <div className="space-y-4">
                {selectedEvidencias.map((evidencia, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center">
                        {evidencia.tipo === 'foto' && <Camera className="h-5 w-5 mr-2 text-green-600" />}
                        {evidencia.tipo === 'documento' && <FileText className="h-5 w-5 mr-2 text-blue-600" />}
                        {evidencia.tipo === 'relatório' && <FileText className="h-5 w-5 mr-2 text-purple-600" />}
                        <span className="font-medium capitalize">{evidencia.tipo}</span>
                      </div>
                      <span className="text-sm text-gray-500">{formatDate(evidencia.data)}</span>
                    </div>
                    {evidencia.descricao && (
                      <p className="text-sm text-gray-600 mb-2">{evidencia.descricao}</p>
                    )}
                    <button
                      onClick={() => window.open(evidencia.url, '_blank')}
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      Ver arquivo →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Tarefas
