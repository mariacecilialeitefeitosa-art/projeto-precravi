
import React, { useEffect, useState } from 'react'
import { Users, Plus, Search, Filter, Eye, Edit, UserCheck } from 'lucide-react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

interface Aluno {
  _id: string
  nome: string
  cpf: string
  rg?: string
  dataNascimento: string
  endereco?: {
    rua?: string
    numero?: string
    bairro?: string
    cidade?: string
    cep?: string
  }
  contato?: {
    telefone?: string
    email?: string
  }
  responsavel?: {
    nome?: string
    telefone?: string
    parentesco?: string
  }
  situacao: 'ativo' | 'inativo' | 'egresso' | 'desistente'
  dataMatricula: string
  curso?: string
  turma?: string
  observacoes?: string
}

const Alunos: React.FC = () => {
  const [alunos, setAlunos] = useState<Aluno[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterSituacao, setFilterSituacao] = useState<string>('todos')
  const [showModal, setShowModal] = useState(false)
  const [selectedAluno, setSelectedAluno] = useState<Aluno | null>(null)
  const [isEditing, setIsEditing] = useState(false)

  useEffect(() => {
    fetchAlunos()
  }, [])

  const fetchAlunos = async () => {
    try {
      setLoading(true)
      const response = await lumi.entities.alunos.list()
      setAlunos(response.list || [])
    } catch (error) {
      console.error('Erro ao carregar alunos:', error)
      toast.error('Erro ao carregar lista de alunos')
    } finally {
      setLoading(false)
    }
  }

  const filteredAlunos = alunos.filter(aluno => {
    const matchesSearch = aluno.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         aluno.cpf.includes(searchTerm) ||
                         (aluno.curso && aluno.curso.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesFilter = filterSituacao === 'todos' || aluno.situacao === filterSituacao
    
    return matchesSearch && matchesFilter
  })

  const getSituacaoColor = (situacao: string) => {
    switch (situacao) {
      case 'ativo':
        return 'bg-green-100 text-green-800'
      case 'egresso':
        return 'bg-blue-100 text-blue-800'
      case 'inativo':
        return 'bg-gray-100 text-gray-800'
      case 'desistente':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const openModal = (aluno?: Aluno) => {
    setSelectedAluno(aluno || null)
    setIsEditing(!!aluno)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedAluno(null)
    setIsEditing(false)
  }

  const handleSubmit = async (formData: FormData) => {
    try {
      const alunoData = {
        nome: formData.get('nome') as string,
        cpf: formData.get('cpf') as string,
        rg: formData.get('rg') as string,
        dataNascimento: formData.get('dataNascimento') as string,
        endereco: {
          rua: formData.get('rua') as string,
          numero: formData.get('numero') as string,
          bairro: formData.get('bairro') as string,
          cidade: formData.get('cidade') as string,
          cep: formData.get('cep') as string
        },
        contato: {
          telefone: formData.get('telefone') as string,
          email: formData.get('email') as string
        },
        responsavel: {
          nome: formData.get('responsavelNome') as string,
          telefone: formData.get('responsavelTelefone') as string,
          parentesco: formData.get('parentesco') as string
        },
        situacao: formData.get('situacao') as string,
        dataMatricula: formData.get('dataMatricula') as string,
        curso: formData.get('curso') as string,
        turma: formData.get('turma') as string,
        observacoes: formData.get('observacoes') as string,
        creator: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }

      if (isEditing && selectedAluno) {
        await lumi.entities.alunos.update(selectedAluno._id, alunoData)
        toast.success('Aluno atualizado com sucesso')
      } else {
        await lumi.entities.alunos.create(alunoData)
        toast.success('Aluno cadastrado com sucesso')
      }

      closeModal()
      fetchAlunos()
    } catch (error) {
      console.error('Erro ao salvar aluno:', error)
      toast.error('Erro ao salvar aluno')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <Users className="h-8 w-8 mr-3 text-blue-600" />
            Gestão de Alunos
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Controle de matrículas e acompanhamento de alunos ingressantes e egressos
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => openModal()}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            Novo Aluno
          </button>
        </div>
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por nome, CPF ou curso..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="h-5 w-5 absolute left-3 top-3 text-gray-400" />
            <select
              value={filterSituacao}
              onChange={(e) => setFilterSituacao(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="todos">Todas as situações</option>
              <option value="ativo">Ativo</option>
              <option value="egresso">Egresso</option>
              <option value="inativo">Inativo</option>
              <option value="desistente">Desistente</option>
            </select>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <UserCheck className="h-4 w-4" />
            <span>{filteredAlunos.length} aluno(s) encontrado(s)</span>
          </div>
        </div>
      </div>

      {/* Lista de alunos */}
      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Aluno
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Curso/Turma
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Situação
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Matrícula
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contato
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredAlunos.map((aluno) => (
                <tr key={aluno._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{aluno.nome}</div>
                      <div className="text-sm text-gray-500">CPF: {aluno.cpf}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{aluno.curso || '-'}</div>
                    <div className="text-sm text-gray-500">{aluno.turma || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getSituacaoColor(aluno.situacao)}`}>
                      {aluno.situacao}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(aluno.dataMatricula)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div>{aluno.contato?.telefone || '-'}</div>
                    <div>{aluno.contato?.email || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => openModal(aluno)}
                      className="text-blue-600 hover:text-blue-900 mr-3"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de cadastro/edição */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {isEditing ? 'Editar Aluno' : 'Novo Aluno'}
              </h3>
              <form onSubmit={(e) => {
                e.preventDefault()
                handleSubmit(new FormData(e.currentTarget))
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
                    <input
                      type="text"
                      name="nome"
                      required
                      defaultValue={selectedAluno?.nome || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">CPF *</label>
                    <input
                      type="text"
                      name="cpf"
                      required
                      defaultValue={selectedAluno?.cpf || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">RG</label>
                    <input
                      type="text"
                      name="rg"
                      defaultValue={selectedAluno?.rg || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data de Nascimento *</label>
                    <input
                      type="date"
                      name="dataNascimento"
                      required
                      defaultValue={selectedAluno?.dataNascimento ? selectedAluno.dataNascimento.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                    <input
                      type="text"
                      name="telefone"
                      defaultValue={selectedAluno?.contato?.telefone || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      name="email"
                      defaultValue={selectedAluno?.contato?.email || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Curso</label>
                    <select
                      name="curso"
                      defaultValue={selectedAluno?.curso || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="">Selecione um curso</option>
                      <option value="Gestão Industrial">Gestão Industrial</option>
                      <option value="Técnico em Informática">Técnico em Informática</option>
                      <option value="Administração">Administração</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Turma</label>
                    <input
                      type="text"
                      name="turma"
                      defaultValue={selectedAluno?.turma || ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Situação *</label>
                    <select
                      name="situacao"
                      required
                      defaultValue={selectedAluno?.situacao || 'ativo'}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="ativo">Ativo</option>
                      <option value="inativo">Inativo</option>
                      <option value="egresso">Egresso</option>
                      <option value="desistente">Desistente</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Data de Matrícula *</label>
                    <input
                      type="date"
                      name="dataMatricula"
                      required
                      defaultValue={selectedAluno?.dataMatricula ? selectedAluno.dataMatricula.split('T')[0] : ''}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                  <textarea
                    name="observacoes"
                    rows={3}
                    defaultValue={selectedAluno?.observacoes || ''}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {isEditing ? 'Atualizar' : 'Cadastrar'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Alunos
