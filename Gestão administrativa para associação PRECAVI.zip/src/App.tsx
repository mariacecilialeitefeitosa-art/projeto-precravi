
import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Alunos from './pages/Alunos'
import Documentos from './pages/Documentos'
import VisitasTecnicas from './pages/VisitasTecnicas'
import Eventos from './pages/Eventos'
import Tarefas from './pages/Tarefas'

function App() {
  return (
    <>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#1f2937',
            color: '#f9fafb',
            border: '1px solid #374151'
          },
          success: {
            style: {
              background: '#065f46',
              color: '#ecfdf5'
            }
          },
          error: {
            style: {
              background: '#7f1d1d',
              color: '#fef2f2'
            }
          }
        }}
      />
      
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/alunos" element={<Alunos />} />
            <Route path="/documentos" element={<Documentos />} />
            <Route path="/visitas-tecnicas" element={<VisitasTecnicas />} />
            <Route path="/eventos" element={<Eventos />} />
            <Route path="/tarefas" element={<Tarefas />} />
          </Routes>
        </Layout>
      </Router>
    </>
  )
}

export default App
